# This is read me 
# Then package name is wzc_mypackage